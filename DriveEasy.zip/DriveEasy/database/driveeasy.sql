CREATE DATABASE IF NOT EXISTS driveeasy;
USE driveeasy;

CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(100) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  phone VARCHAR(20),
  role ENUM('user','admin') DEFAULT 'user',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS cars (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  brand VARCHAR(50) NOT NULL,
  type VARCHAR(30) NOT NULL,
  seats INT NOT NULL,
  fuel VARCHAR(20) NOT NULL,
  transmission VARCHAR(20) NOT NULL,
  price_per_day DECIMAL(10,2) NOT NULL,
  image_url VARCHAR(500),
  available TINYINT(1) DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS bookings (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  car_id INT NOT NULL,
  start_date DATE NOT NULL,
  end_date DATE NOT NULL,
  total_price DECIMAL(10,2) NOT NULL,
  status ENUM('confirmed','cancelled','completed') DEFAULT 'confirmed',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (car_id) REFERENCES cars(id) ON DELETE CASCADE
);

INSERT INTO cars (name, brand, type, seats, fuel, transmission, price_per_day, image_url) VALUES
('Swift VXi', 'Maruti Suzuki', 'Hatchback', 5, 'Petrol', 'Manual', 1500, 'https://images.unsplash.com/photo-1494976388531-d1058494cdd8?w=600'),
('Creta SX', 'Hyundai', 'SUV', 5, 'Diesel', 'Automatic', 3200, 'https://images.unsplash.com/photo-1503376780353-7e6692767b70?w=600'),
('Innova Crysta', 'Toyota', 'MPV', 7, 'Diesel', 'Manual', 3800, 'https://images.unsplash.com/photo-1549317661-bd32c8ce0db2?w=600'),
('City ZX', 'Honda', 'Sedan', 5, 'Petrol', 'Automatic', 2600, 'https://images.unsplash.com/photo-1552519507-da3b142c6e3d?w=600'),
('Nexon EV', 'Tata', 'SUV', 5, 'Electric', 'Automatic', 3000, 'https://images.unsplash.com/photo-1583121274602-3e2820c69888?w=600'),
('Thar LX', 'Mahindra', 'SUV', 4, 'Diesel', 'Manual', 3500, 'https://images.unsplash.com/photo-1533473359331-0135ef1b58bf?w=600');
