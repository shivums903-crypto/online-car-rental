require('dotenv').config();
const express = require('express');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const db = require('./config/db');

const app = express();
app.use(cors());
app.use(express.json());

app.use('/api/auth', require('./routes/auth'));
app.use('/api/cars', require('./routes/cars'));
app.use('/api/bookings', require('./routes/bookings'));

app.get('/api/health', (req, res) => res.json({ ok: true }));

// Create a default admin account on first run
async function ensureAdmin() {
  const [rows] = await db.query("SELECT id FROM users WHERE role = 'admin' LIMIT 1");
  if (!rows.length) {
    const hash = await bcrypt.hash('admin123', 10);
    await db.query(
      "INSERT INTO users (name, email, password, role) VALUES ('Admin', 'admin@driveeasy.com', ?, 'admin')",
      [hash]
    );
    console.log('Default admin created: admin@driveeasy.com / admin123');
  }
}

const PORT = process.env.PORT || 5000;
db.query('SELECT 1')
  .then(async () => {
    console.log('MySQL connected');
    await ensureAdmin();
    app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
  })
  .catch((err) => {
    console.error('Database connection failed:', err.message);
    process.exit(1);
  });
