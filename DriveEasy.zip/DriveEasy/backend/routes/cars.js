const router = require('express').Router();
const db = require('../config/db');
const { protect, adminOnly } = require('../middleware/auth');

// List cars. Optional filters: type, fuel, maxPrice, startDate + endDate (hides cars already booked)
router.get('/', async (req, res) => {
  try {
    const { type, fuel, maxPrice, startDate, endDate } = req.query;
    let sql = 'SELECT * FROM cars WHERE available = 1';
    const params = [];
    if (type) { sql += ' AND type = ?'; params.push(type); }
    if (fuel) { sql += ' AND fuel = ?'; params.push(fuel); }
    if (maxPrice) { sql += ' AND price_per_day <= ?'; params.push(maxPrice); }
    if (startDate && endDate) {
      sql += ` AND id NOT IN (
        SELECT car_id FROM bookings
        WHERE status = 'confirmed' AND start_date <= ? AND end_date >= ?)`;
      params.push(endDate, startDate);
    }
    const [rows] = await db.query(sql + ' ORDER BY price_per_day', params);
    res.json(rows);
  } catch (e) {
    console.error(e);
    res.status(500).json({ message: 'Server error.' });
  }
});

router.get('/:id', async (req, res) => {
  const [rows] = await db.query('SELECT * FROM cars WHERE id = ?', [req.params.id]);
  if (!rows.length) return res.status(404).json({ message: 'Car not found.' });
  res.json(rows[0]);
});

router.post('/', protect, adminOnly, async (req, res) => {
  try {
    const { name, brand, type, seats, fuel, transmission, price_per_day, image_url } = req.body;
    if (!name || !brand || !type || !seats || !fuel || !transmission || !price_per_day)
      return res.status(400).json({ message: 'Please fill in all required fields.' });
    const [r] = await db.query(
      `INSERT INTO cars (name, brand, type, seats, fuel, transmission, price_per_day, image_url)
       VALUES (?,?,?,?,?,?,?,?)`,
      [name, brand, type, seats, fuel, transmission, price_per_day, image_url || null]
    );
    res.status(201).json({ id: r.insertId });
  } catch (e) {
    console.error(e);
    res.status(500).json({ message: 'Server error.' });
  }
});

router.put('/:id', protect, adminOnly, async (req, res) => {
  const { price_per_day, available } = req.body;
  await db.query(
    'UPDATE cars SET price_per_day = COALESCE(?, price_per_day), available = COALESCE(?, available) WHERE id = ?',
    [price_per_day ?? null, available ?? null, req.params.id]
  );
  res.json({ message: 'Car updated.' });
});

router.delete('/:id', protect, adminOnly, async (req, res) => {
  await db.query('DELETE FROM cars WHERE id = ?', [req.params.id]);
  res.json({ message: 'Car deleted.' });
});

module.exports = router;
