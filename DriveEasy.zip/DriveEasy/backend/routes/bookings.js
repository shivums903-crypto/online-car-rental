const router = require('express').Router();
const db = require('../config/db');
const { protect, adminOnly } = require('../middleware/auth');

// Create a booking
router.post('/', protect, async (req, res) => {
  try {
    const { car_id, start_date, end_date } = req.body;
    if (!car_id || !start_date || !end_date)
      return res.status(400).json({ message: 'Choose a car and both dates.' });

    const start = new Date(start_date);
    const end = new Date(end_date);
    const today = new Date(); today.setHours(0, 0, 0, 0);
    if (start < today) return res.status(400).json({ message: 'Start date cannot be in the past.' });
    if (end < start) return res.status(400).json({ message: 'End date must be on or after the start date.' });

    const [cars] = await db.query('SELECT * FROM cars WHERE id = ? AND available = 1', [car_id]);
    if (!cars.length) return res.status(404).json({ message: 'This car is not available.' });

    const [clash] = await db.query(
      `SELECT id FROM bookings
       WHERE car_id = ? AND status = 'confirmed' AND start_date <= ? AND end_date >= ?`,
      [car_id, end_date, start_date]
    );
    if (clash.length)
      return res.status(409).json({ message: 'This car is already booked for those dates.' });

    const days = Math.round((end - start) / 86400000) + 1;
    const total = days * Number(cars[0].price_per_day);
    const [r] = await db.query(
      'INSERT INTO bookings (user_id, car_id, start_date, end_date, total_price) VALUES (?,?,?,?,?)',
      [req.user.id, car_id, start_date, end_date, total]
    );
    res.status(201).json({ id: r.insertId, days, total_price: total });
  } catch (e) {
    console.error(e);
    res.status(500).json({ message: 'Server error.' });
  }
});

// My bookings
router.get('/mine', protect, async (req, res) => {
  const [rows] = await db.query(
    `SELECT b.*, c.name AS car_name, c.brand, c.image_url
     FROM bookings b JOIN cars c ON c.id = b.car_id
     WHERE b.user_id = ? ORDER BY b.created_at DESC`,
    [req.user.id]
  );
  res.json(rows);
});

// Cancel my booking
router.put('/:id/cancel', protect, async (req, res) => {
  const [r] = await db.query(
    `UPDATE bookings SET status = 'cancelled'
     WHERE id = ? AND user_id = ? AND status = 'confirmed'`,
    [req.params.id, req.user.id]
  );
  if (!r.affectedRows) return res.status(404).json({ message: 'Booking cannot be cancelled.' });
  res.json({ message: 'Booking cancelled.' });
});

// Admin: all bookings
router.get('/', protect, adminOnly, async (req, res) => {
  const [rows] = await db.query(
    `SELECT b.*, c.name AS car_name, u.name AS user_name, u.email
     FROM bookings b
     JOIN cars c ON c.id = b.car_id
     JOIN users u ON u.id = b.user_id
     ORDER BY b.created_at DESC`
  );
  res.json(rows);
});

// Admin: update status
router.put('/:id/status', protect, adminOnly, async (req, res) => {
  const { status } = req.body;
  if (!['confirmed', 'cancelled', 'completed'].includes(status))
    return res.status(400).json({ message: 'Invalid status.' });
  await db.query('UPDATE bookings SET status = ? WHERE id = ?', [status, req.params.id]);
  res.json({ message: 'Status updated.' });
});

module.exports = router;
